import java.io.File;
import java.util.*;

public class Database {
	
	/* class for the AVL tree */
    public class Tree_tid
    {
    	/* node of the AVL tree */
    public class Node
        {
            long data;
            int T_elements=1;
            Node right;
            Node left;
        }
    long N=0;
    Node head=null;
    /* function for the left-subtree rotation */
    public Node Rotate_Left(Node root)
        {
            int root_right=root.right.T_elements;
            int root_E=root.T_elements;
            Node temp1=root.right;
            Node temp2=temp1.left;
            temp1.left=root;
            root.right=temp2;
            temp1.T_elements=root_E;
            int sum=1;
            if(temp1.left.right!=null)
                sum+=temp1.left.right.T_elements;
            if(temp1.left.left!=null)
                sum+=temp1.left.left.T_elements;
            temp1.left.T_elements=sum;
            return temp1;
        }
        /* function for the right-subtree rotation */
        public Node Rotate_Right(Node root)
            {
            int root_left=root.left.T_elements;
            int root_E=root.T_elements;
            Node temp1=root.left;
            Node temp2=temp1.right;
            temp1.right=root;
            root.left=temp2;
            temp1.T_elements=root_E;
            int sum=1;
            if(temp1.right.left!=null)
                sum+=temp1.right.left.T_elements;
            if(temp1.right.right!=null)
                sum+=temp1.right.right.T_elements;
            temp1.right.T_elements=sum;
            return temp1;
            }
        /* function that inserts and incoming element */
        public void Insert(long element)
            {
                head=Insert_Into_Tree(head,element);
                N++;
            }
        /* recursive function for the above insert function */
        public Node Insert_Into_Tree(Node root,long data)
        {
            Node temp=new Node();
            temp.data=data;
            temp.T_elements=1;
            if(root==null)
                return temp;
            else
            {
            if(root.data>data)
                {
                    root.T_elements+=1;
                    root.left=Insert_Into_Tree(root.left,data);
                }
            else
                {
                    root.T_elements+=1;
                    root.right=Insert_Into_Tree(root.right,data);
                }
            int lt=0,rt=0;
            if(root.left!=null)   
             lt=root.left.T_elements;
            if(root.right!=null)
             rt=root.right.T_elements;
            int dif=lt-rt;
            if(dif>1)
                {
                    if(Elements_No(root.left.right)<Elements_No(root.left.left))
                        root=Rotate_Right(root);
                    else
                        {
                         root.left=Rotate_Left(root.left);
		                 root=Rotate_Right(root); 
                        }
                }
             else if(dif<-1)
                 {
                    if(Elements_No(root.right.left)<Elements_No(root.right.right))
                        root=Rotate_Left(root);
                    else
                        {
                            root.right=Rotate_Right(root.right);
                            root=Rotate_Left(root);
                        }
                }
                return root;
            }
        }
        /* function that keeps track of the no of element's no */
        public int Elements_No(Node root)
        {
            if(root==null)
                return 0;
            else
            {
                return root.T_elements;
            }
        }
        /* function to minimum */
        public long minimum()
        {
        	Node Min=Findmin(head);
        	return Min.data;
        }
        /* function to maximum */
        public long maximum()
        {
        	Node Max=Findmax(head);
        	return Max.data;
        }
        /* function which is called by above function to calculate minimum */
    	public Node Findmin(Node root)
    	{
    		while(root.left!=null)
    		{
    			root=root.left;
    		}
    		return root;
    	}
    	/* function which is called by above function to calculate maximum */
    	public Node Findmax(Node root)
    	{
    		while(root.right!=null)
    		{
    			root=root.right;
    		}
    		return root;
    	}
    	/* function to remove a data from tree */
        public void Remove(long data)
        {
        	if(check_present(head,data))
        	{
        		head=Remove_Element(head,data);
                N--;
        	}
        }
        /* recursive function called by above function to remove a data from tree */
        public Node Remove_Element(Node root,long data)
        {
        	if(root!=null)
        	{
        		if(root.data>data)
        		{
        			root.T_elements-=1;
        			root.left=Remove_Element(root.left,data);
        		}
        		else if(root.data<data)
        		{
        			root.T_elements-=1;
        			root.right=Remove_Element(root.right,data);
        		}
        		else
        		{
        			if(root.right==null && root.left==null)
        				return null;
        			else if(root.left==null && root.right!=null)
        				return root.right;
        			else if(root.left!=null && root.right==null)
        				return root.left;
        			else
        			{
    					Node temp=Findmin(root.right);
    					root.data=temp.data;
                        root.T_elements-=1;
    					root.right=Remove_Element(root.right,root.data);
    				}
    			}
				return root;
    		}
    		else
    		{
    			return null;
    		}
    	}
    /* function to check is the required data is present in the tree */
    public boolean check_present(Node root,long data)
    {
    	if(root==null)
    		return false;
    	else
    	{
    		if(root.data==data)
    			return true;
    		else if(root.data>data)
    			return check_present(root.left,data);
    		else
    			return check_present(root.right,data);
    	}
    }
    }
    
    /* AVL tree for the cost */
    public class Tree_cost
    {
    /* node class for the cost AVL tree  */
    public class Node
        {
            double data;
            int T_elements=1;
            Node right;
            Node left;
        }
    long N=0;
    Node head=null;
    /* function for the left-subtree rotation */
    public Node Rotate_Left(Node root)
        {
            int root_right=root.right.T_elements;
            int root_E=root.T_elements;
            Node temp1=root.right;
            Node temp2=temp1.left;
            temp1.left=root;
            root.right=temp2;
            temp1.T_elements=root_E;
            int sum=1;
            if(temp1.left.right!=null)
                sum+=temp1.left.right.T_elements;
            if(temp1.left.left!=null)
                sum+=temp1.left.left.T_elements;
            temp1.left.T_elements=sum;
            return temp1;
        }
        /* function for the right-subtree rotation */
        public Node Rotate_Right(Node root)
            {
            int root_left=root.left.T_elements;
            int root_E=root.T_elements;
            Node temp1=root.left;
            Node temp2=temp1.right;
            temp1.right=root;
            root.left=temp2;
            temp1.T_elements=root_E;
            int sum=1;
            if(temp1.right.left!=null)
                sum+=temp1.right.left.T_elements;
            if(temp1.right.right!=null)
                sum+=temp1.right.right.T_elements;
            temp1.right.T_elements=sum;
            return temp1;
            }
        /* function that inserts and incoming element */
        public void Insert(double element)
            {
                head=Insert_Into_Tree(head,element);
                N++;
            }
        /* recursive function for the above insert function */
        public Node Insert_Into_Tree(Node root,double data)
        {
            Node temp=new Node();
            temp.data=data;
            temp.T_elements=1;
            if(root==null)
                return temp;
            else
            {
            if(root.data>data)
                {
                    root.T_elements+=1;
                    root.left=Insert_Into_Tree(root.left,data);
                }
            else
                {
                    root.T_elements+=1;
                    root.right=Insert_Into_Tree(root.right,data);
                }
            int lt=0,rt=0;
            if(root.left!=null)   
             lt=root.left.T_elements;
            if(root.right!=null)
             rt=root.right.T_elements;
            int dif=lt-rt;
            if(dif>1)
                {
                    if(Elements_No(root.left.right)<Elements_No(root.left.left))
                        root=Rotate_Right(root);
                    else
                        {
                         root.left=Rotate_Left(root.left);
		                 root=Rotate_Right(root); 
                        }
                }
             else if(dif<-1)
                 {
                    if(Elements_No(root.right.left)<Elements_No(root.right.right))
                        root=Rotate_Left(root);
                    else
                        {
                            root.right=Rotate_Right(root.right);
                            root=Rotate_Left(root);
                        }
                }
                return root;
            }
        }
        /* function that keeps track of the no of element's no */
        public int Elements_No(Node root)
        {
            if(root==null)
                return 0;
            else
            {
                return root.T_elements;
            }
        }
        /* function to minimum */
        public double minimum()
        {
        	Node Min=Findmin(head);return Min.data;
        }
        /* function to maximum */
        public double maximum()
        {
        	Node Max=Findmax(head);return Max.data;
        }
        /* function which is called by above function to calculate minimum */
    	public Node Findmin(Node root)
    	{
    		while(root.left!=null)
    		{
    			root=root.left;
    		}
    		return root;
    	}
    	/* function which is called by above function to calculate maximum */
    	public Node Findmax(Node root)
    	{
    		while(root.right!=null)
    		{
    			root=root.right;
    		}
    		return root;
    	}
    	/* function to remove a data from tree */
        public void Remove(double data)
        {
        	if(check_present(head,data))
        	{
        		head=Remove_Element(head,data);
                N--;
        	}
        }
        /* recursive function called by above function to remove a data from tree */
        public Node Remove_Element(Node root,double data)
        {
        	if(root!=null)
        	{
        		if(root.data>data)
        		{
        			root.T_elements-=1;
        			root.left=Remove_Element(root.left,data);
        		}
        		else if(root.data<data)
        		{
        			root.T_elements-=1;
        			root.right=Remove_Element(root.right,data);
        		}
        		else
        		{
        			if(root.right==null && root.left==null)
        				return null;
        			else if(root.left==null && root.right!=null)
        				return root.right;
        			else if(root.left!=null && root.right==null)
        				return root.left;
        			else
        			{
    					Node temp=Findmin(root.right);
    					root.data=temp.data;
                        root.T_elements-=1;
    					root.right=Remove_Element(root.right,root.data);
    				}
    			}
				return root;
    		}
    		else
    		{
    			return null;
    		}
    	}
    /* function to check is the required data is present in the tree */
    public boolean check_present(Node root,double data)
    {
    	if(root==null)
    		return false;
    	else
    	{
    		if(root.data==data)
    			return true;
    		else if(root.data>data)
    			return check_present(root.left,data);
    		else
    			return check_present(root.right,data);
    	}
    }
    }
    
    /* function that reads the input file for database management*/
    public  static String readfile(String directory)
    {
    	String s1="";
    	try
    	{
    		Scanner inp=new Scanner(new File(directory));
    		while(inp.hasNextLine())
    		{
    			String s=inp.nextLine();
    			s1+=s+"_!_";
    		}
    	}
    	catch(Exception e){}
    	return s1;
    }
    
    /* main function starts from here*/
    public static void main(String args[])
    {
    	System.out.println("Please enter the file path which contains the text doxument for the  database manipulation:");
    	Scanner input=new Scanner(System.in);
    	String directory=input.next();
    	String data=readfile(directory);
    	HashMap<String,HashMap<Integer,Double>> Map=new HashMap<String,HashMap<Integer,Double>>();
    	HashMap<Integer,String> T_Map=new HashMap<Integer,String>();
    	Database.Tree_cost T_C=new Database().new Tree_cost();
    	Database.Tree_tid T_ID=new Database().new Tree_tid();
    	String query[]=data.split("_!_");
    	for(int i=0;i<query.length;i++)
    	{
    	String precise_query[]=query[i].split(" ");
    	if(precise_query[0].equals("i"))
    	{
    		if(Map.containsKey(precise_query[2]))
    		{
    			Map.get(precise_query[2]).put(Integer.parseInt(precise_query[1]),Double.parseDouble(precise_query[3]));
    		}
    		else
    		{
    			HashMap<Integer,Double> temp=new HashMap<Integer,Double>();
    			temp.put(Integer.parseInt(precise_query[1]),Double.parseDouble(precise_query[3]));
    			Map.put(precise_query[2],temp);
    		}
    		T_C.Insert(Double.parseDouble(precise_query[3]));
    		T_ID.Insert((long)Integer.parseInt(precise_query[1]));
    		T_Map.put(Integer.parseInt(precise_query[1]),precise_query[2]);
    	}
    	/*else if(precise_query[0].equals("u"))
    	{
    		double price=Map.get(precise_query[2]).get(Integer.parseInt(precise_query[1]));
    		T_C.Remove(price);
    		Map.get(precise_query[2]).remove(Integer.parseInt(precise_query[1]));
    		T_C.Insert(Double.parseDouble(precise_query[3]));
    	}*/
    	else if(precise_query[0].equals("d"))
    	{
    		for(int k=1;k<precise_query.length-2;k++)
    		{
    		if(precise_query[k].equals("tid") && precise_query[k+1].equals("="))
    		{
    			try{
    			String item=T_Map.get(Integer.parseInt(precise_query[k+2]));
    			T_Map.remove(Integer.parseInt(precise_query[k+2]));
    			double cost=Map.get(item).get(Integer.parseInt(precise_query[k+2]));
    			T_C.Remove(cost);
    			T_ID.Remove((long)Integer.parseInt(precise_query[k+2]));
    			Map.get(item).remove(Integer.parseInt(precise_query[k+2]));}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("item") && precise_query[k+1].equals("="))
    		{
    			try{
    			for(int l:Map.get(precise_query[k+2]).keySet())
    			{
    				T_Map.remove(l);
    				T_C.Remove(Map.get(precise_query[k+2]).get(l));
    				T_ID.Remove((long)l);
    			}
    			Map.remove(precise_query[k+2]);}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("="))
    		{
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				try{
    				for(int l:temporary.keySet())
    				{
    					double cost=temporary.get(l);
    					if(cost==Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(temporary);
    						T_C.Remove(cost);T_ID.Remove(l);T_Map.remove(l);Map.get(h).remove(l);
    						temporary=Map.get(h);
    						System.out.println(Map.get(h));
    					}
    				}
    				}catch(Exception e){}
    			}
    		}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals(">"))
    		{ try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>Integer.parseInt(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    		}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals("<"))
    		{
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l<Integer.parseInt(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    		}catch(Exception e){}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals(">="))
    		{ 
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>=Integer.parseInt(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    		}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals("<="))
    		{ 
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>Integer.parseInt(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    		}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals(">"))
    		{
    			try{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>Double.parseDouble(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}}catch(Exception e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("<"))
    		{
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)<Double.parseDouble(precise_query[k+2]))
    					{
    					int m=l;
    					System.out.println(temporary);
    					}
    				}
    			}
        		}catch(NullPointerException e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals(">="))
    		{
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>=Double.parseDouble(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    			}catch(Exception e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("<="))
    		{
    			try {
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>Double.parseDouble(precise_query[k+2]))
    					{
    						T_Map.remove(l);
    						T_C.Remove(temporary.get(l));
    						T_ID.Remove(l);
    						Map.get(h).remove(l);
    					}
    				}
    			}
    		}catch(Exception e){}
    		}
    		}
    	}
    	else if(precise_query[0].equals("s"))
    	{
    		try {
    		for(int k=1;k<precise_query.length-2;k++)
    		{
    		if(precise_query[k].equals("tid") && precise_query[k+1].equals("="))
    		{
    			try{
    			String item=T_Map.get(Integer.parseInt(precise_query[k+2]));
    			double cost=Map.get(item).get(Integer.parseInt(precise_query[k+2]));
    			System.out.println(precise_query[k+2]+" "+item+" "+cost);}catch(Exception e){}
    		}
    		else if(precise_query[k].equals("item") && precise_query[k+1].equals("="))
    		{
    			try{
    			for(int l:Map.get(precise_query[k+2]).keySet())
    			{
    				System.out.println(l+" "+precise_query[k+2]+" "+Map.get(precise_query[k+2]).get(l));
    			}
    			}catch(Exception e){}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("="))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					double cost=temporary.get(l);
    					if(cost==Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals(">"))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>Integer.parseInt(precise_query[k+2]))
    					{	
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals("<"))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l<Integer.parseInt(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals(">="))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>=Integer.parseInt(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("tid") && precise_query[k+1].equals("<="))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(l>Integer.parseInt(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals(">"))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l)+"sdf");
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("<"))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)<Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals(">="))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>=Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    		}
    		else if(precise_query[k].equals("cost") && precise_query[k+1].equals("<="))
    		{
    			for(String h:Map.keySet())
    			{
    				HashMap<Integer,Double> temporary=Map.get(h);
    				for(int l:temporary.keySet())
    				{
    					if(temporary.get(l)>Double.parseDouble(precise_query[k+2]))
    					{
    						System.out.println(l+" "+h+" "+Map.get(h).get(l));
    					}
    				}
    			}
    			
    		}
    		System.out.println();
    		}
    	}catch(Exception e){}
    	}
    	}
    }
}